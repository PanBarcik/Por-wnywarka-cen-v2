import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'features/scanner/presentation/bloc/scanner_bloc.dart';
import 'features/scanner/presentation/pages/home_page.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // 1. Inicjalizacja bazowej aplikacji Firebase
  final app = await Firebase.initializeApp();
  
  // 2. Wskazanie konkretnej bazy o nazwie 'powornywarka' przy użyciu zmiennej 'app'
  FirebaseFirestore.instanceFor(app: app, databaseId: 'powornywarka');
  
  // 3. Uruchomienie aplikacji
  runApp(
    BlocProvider<ScannerBloc>(
      create: (context) => ScannerBloc(),
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Porównywarka Cen',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF111827),
      ),
      home: const HomePage(),
    );
  }
}