import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:googleapis_auth/auth_io.dart';

class GoogleCloudAuth {
  // Funkcja autoryzuje aplikację w Google Cloud przy użyciu Twojego pliku JSON
  Future<AutoRefreshingAuthClient> getAuthenticatedClient() async {
    final jsonString = await rootBundle.loadString('assets/credentials.json');
    final jsonKey = json.decode(jsonString);
    
    // Zakres uprawnień wymagany do operacji na Speech-to-Text oraz Vision
    final scopes = ['https://www.googleapis.com/auth/cloud-platform'];
    
    final credentials = ServiceAccountCredentials.fromJson(jsonKey);
    return await clientViaServiceAccount(credentials, scopes);
  }
}