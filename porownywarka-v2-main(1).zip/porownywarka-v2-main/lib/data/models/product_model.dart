class ProductModel {
  final String ean;
  final String nazwa;
  final String marka;
  final String kategoria;
  final Map<String, double> ceny;

  ProductModel({
    required this.ean,
    required this.nazwa,
    required this.marka,
    required this.kategoria,
    required this.ceny,
  });

  factory ProductModel.fromFirestore(Map<String, dynamic> json, String docId) {
    final cenaMap = json['Cena'] as Map<String, dynamic>? ?? {};
    final Map<String, double> mappedPrices = {};
    
    cenaMap.forEach((key, value) {
      mappedPrices[key] = (value is num) ? value.toDouble() : 0.0;
    });

    return ProductModel(
      ean: docId,
      nazwa: json['Nazwa'] ?? 'Nieznany produkt',
      marka: json['Marka'] ?? 'Nieznana marka',
      kategoria: json['Kategoria'] ?? 'Inne',
      ceny: mappedPrices,
    );
  }
}