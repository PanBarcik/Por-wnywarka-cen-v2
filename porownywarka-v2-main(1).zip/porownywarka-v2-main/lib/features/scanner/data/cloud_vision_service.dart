import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

class CloudVisionService {
  // 1. TUTAJ WPISZ SWÓJ KLUCZ API Z KONSOLI GOOGLE
  final String _apiKey = "AIzaSyA-vrWrCqp099T0FvNCQ7sPxyCJUeoLOLw";

  Future<String?> detectBarcodeOrText(File imageFile) async {
    try {
      // 2. Przygotowanie zdjęcia do formatu Base64
      List<int> imageBytes = await imageFile.readAsBytes();
      String base64Image = base64Encode(imageBytes);

      final Map<String, dynamic> requestBody = {
        "requests": [
          {
            "image": {"content": base64Image},
            "features": [
              {"type": "TEXT_DETECTION", "maxResults": 1}
            ]
          }
        ]
      };

      // 3. Wysłanie prostego zapytania z kluczem API w adresie URL
      final response = await http.post(
        Uri.parse("https://vision.googleapis.com/v1/images:annotate?key=$_apiKey"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode(requestBody),
      );

      if (response.statusCode == 200) {
        final jsonResponse = jsonDecode(response.body);
        final List? responses = jsonResponse['responses'];
        
        if (responses != null && responses.isNotEmpty) {
          final textAnnotations = responses[0]['textAnnotations'];
          if (textAnnotations != null && textAnnotations.isNotEmpty) {
            String fullText = textAnnotations[0]['description'];
            return _extractEanCode(fullText);
          }
        }
      } else {
        print("Błąd serwera Google Vision: ${response.statusCode} - ${response.body}");
      }
      return null;
    } catch (e) {
      print("Błąd Cloud Vision: $e");
      return null;
    }
  }

  // Wyciąganie ciągu cyfr (EAN) z przetworzonego tekstu (kod kolegi, zostawiamy go)
  String? _extractEanCode(String text) {
    final RegExp eanRegex = RegExp(r'\b\d{8,13}\b');
    final match = eanRegex.firstMatch(text.replaceAll(RegExp(r'\s+'), ''));
    return match?.group(0);
  }
}