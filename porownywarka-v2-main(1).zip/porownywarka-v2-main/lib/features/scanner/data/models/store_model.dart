import 'package:flutter/material.dart';

class StoreModel {
  final String name;
  final IconData icon;

  const StoreModel({
    required this.name,
    required this.icon,
  });
}