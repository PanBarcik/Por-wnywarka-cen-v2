class ProductModel {
  final String title;
  final String timeAgo;
  final double currentPrice;
  final double? oldPrice;
  final String storeName;
  final String? competitorStoreName;
  final String imageUrl;

  const ProductModel({
    required this.title,
    required this.timeAgo,
    required this.currentPrice,
    this.oldPrice,
    required this.storeName,
    this.competitorStoreName,
    required this.imageUrl,
  });

  bool get hasBestPrice => oldPrice != null;
}