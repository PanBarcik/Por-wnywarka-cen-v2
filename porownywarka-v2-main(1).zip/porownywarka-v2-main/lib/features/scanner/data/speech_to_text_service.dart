import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter_sound/flutter_sound.dart';
import 'package:path_provider/path_provider.dart';
import 'package:http/http.dart' as http;

class SpeechToTextService {
  final FlutterSoundRecorder _recorder = FlutterSoundRecorder();
  String? _localPath;
  bool _isRecorderInitialized = false;

  // 1. TUTAJ WPISZ SWÓJ KLUCZ API Z KONSOLI GOOGLE
  final String _apiKey = "AIzaSyA-vrWrCqp099T0FvNCQ7sPxyCJUeoLOLw";

  Future<void> _initRecorder() async {
    if (!_isRecorderInitialized) {
      await _recorder.openRecorder();
      _isRecorderInitialized = true;
    }
  }

  Future<void> startRecording() async {
    await _initRecorder();
    final directory = await getTemporaryDirectory();
    _localPath = '${directory.path}/speech_input.aac';
    
    // Start nagrywania w formacie AAC
    await _recorder.startRecorder(
      toFile: _localPath,
      codec: Codec.aacADTS,
    );
  }

  Future<String?> stopRecordingAndRecognize() async {
    if (!_isRecorderInitialized) return null;
    
    // Zatrzymanie nagrywania
    await _recorder.stopRecorder();
    if (_localPath == null) return null;

    final file = File(_localPath!);
    if (!await file.exists()) return null;

    try {
      final audioBytes = await file.readAsBytes();
      final base64Audio = base64Encode(audioBytes);

      // Przygotowanie paczki JSON dla zapytania HTTP
      final Map<String, dynamic> requestBody = {
        "config": {
          "encoding": "AUDIO_ENCODING_UNSPECIFIED", // Google automatycznie wykryje format AAC
          "languageCode": "pl-PL" // Rozpoznawanie mowy po polsku
        },
        "audio": {
          "content": base64Audio
        }
      };

      // Wysłanie zapytania POST bezpośrednio pod adres URL z Kluczem API
      final response = await http.post(
        Uri.parse("https://speech.googleapis.com/v1/speech:recognize?key=$_apiKey"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode(requestBody),
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> jsonResponse = jsonDecode(response.body);
        final List? results = jsonResponse['results'];

        if (results != null && results.isNotEmpty) {
          final List? alternatives = results[0]['alternatives'];
          if (alternatives != null && alternatives.isNotEmpty) {
            // Zwracamy rozpoznany tekst
            return alternatives[0]['transcript'];
          }
        }
      } else {
        debugPrint('Błąd serwera Google Speech: ${response.statusCode} - ${response.body}');
      }
    } catch (e) {
      debugPrint('Błąd połączenia ze Speech API: $e');
    }
    return null;
  }
}