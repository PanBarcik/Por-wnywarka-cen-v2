import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:camera/camera.dart';
import '../bloc/scanner_bloc.dart';
import '../bloc/scanner_event.dart';
import '../bloc/scanner_state.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';

class CameraPage extends StatefulWidget {
  const CameraPage({Key? key}) : super(key: key);

  @override
  State<CameraPage> createState() => _CameraPageState();
}

class _CameraPageState extends State<CameraPage> with SingleTickerProviderStateMixin {
  CameraController? _cameraController;
  List<CameraDescription>? _cameras;
  bool _isCameraInitialized = false;

  late AnimationController _animationController;
  late Animation<double> _laserAnimation;

  @override
  void initState() {
    super.initState();
    _initializeInternalCamera();
    _animationController = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    )..repeat(reverse: true);
    _laserAnimation = Tween<double>(begin: 0.0, end: 200.0).animate(_animationController);
  }

  Future<void> _initializeInternalCamera() async {
    try {
      _cameras = await availableCameras();
      if (_cameras != null && _cameras!.isNotEmpty) {
        _cameraController = CameraController(_cameras![0], ResolutionPreset.medium, enableAudio: false);
        await _cameraController!.initialize();
        if (!mounted) return;
        setState(() { _isCameraInitialized = true; });
      }
    } catch (e) {
      print("Błąd kamery: $e");
    }
  }

  Future<void> _takePictureAndScan() async {
    if (_cameraController == null || !_cameraController!.value.isInitialized) return;
    try {
      final XFile picture = await _cameraController!.takePicture();
      context.read<ScannerBloc>().add(PhotoCaptured(File(picture.path)));
    } catch (e) {
      print("Błąd zdjęcia: $e");
    }
  }

  @override
  void dispose() {
    _cameraController?.dispose();
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    const accentGreen = Color(0xFF22C55E);

    return Scaffold(
      backgroundColor: const Color(0xFF111622),
      appBar: AppBar(
        title: const Text("Skaner", style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => context.read<ScannerBloc>().add(const BackToHomeEvent()),
        ),
      ),
      // BLOC CONSUMER - TO TUTAJ ZMUSZAMY APLIKACJĘ DO WYŚWIETLENIA DANYCH
      body: BlocConsumer<ScannerBloc, ScannerState>(
        listener: (context, state) {
          // 1. Opcja: BŁĄD
          if (state is ScannerError) {
            _showRawDataDialog(context, "🔴 BŁĄD KRYTYCZNY", state.message);
          }
          // 2. Opcja: BRAK W BAZIE
          if (state is ProductNotFound) {
            _showRawDataDialog(context, "🟡 BRAK PRODUKTU", "Baza Firebase odpowiedziała, ale nie znalazła kodu EAN: ${state.ean}");
          }
          // 3. Opcja: ZNALEZIONO! (Wypluwamy surowe dane)
          if (state is ProductFound) {
            _showRawDataDialog(
                context,
                "🟢 ZNALEZIONO W BAZIE!",
                "SUROWE DANE Z FIREBASE:\n\n"
                    "EAN: ${state.product.ean}\n"
                    "NAZWA: ${state.product.nazwa}\n"
                    "MARKA: ${state.product.marka}\n"
                    "KATEGORIA: ${state.product.kategoria}\n"
                    "CENY (MAPA): ${state.product.ceny.toString()}"
            );
          }
        },
        builder: (context, state) {
          if (state is ScannerLoading) {
            return const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(color: accentGreen),
                  SizedBox(height: 16),
                  Text("Łączenie z Firebase...", style: TextStyle(color: Colors.white, fontSize: 18)),
                ],
              ),
            );
          }

          // WIDOK KAMERY I PRZYCISKU RĘCZNEGO WPISYWANIA
          return Stack(
            children: [
              if (_isCameraInitialized && _cameraController != null)
                Positioned.fill(child: CameraPreview(_cameraController!))
              else
                const Positioned.fill(child: Center(child: CircularProgressIndicator(color: accentGreen))),

              Positioned.fill(child: Container(color: Colors.black.withOpacity(0.4))),

              Positioned(
                bottom: 40, left: 0, right: 0,
                child: Center(
                  child: OutlinedButton.icon(
                    style: OutlinedButton.styleFrom(
                      backgroundColor: const Color(0xFF0F172A),
                      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
                    ),
                    icon: const Icon(Icons.keyboard_outlined, color: Colors.white),
                    label: const Text("Wpisz Kod Ręcznie", style: TextStyle(color: Colors.white)),
                    onPressed: () {
                      showDialog(
                        context: context,
                        builder: (BuildContext dialogContext) {
                          final TextEditingController barcodeController = TextEditingController();
                          return AlertDialog(
                            backgroundColor: const Color(0xFF1F2937),
                            title: const Text('Wpisz EAN (z zerami!)', style: TextStyle(color: Colors.white)),
                            content: TextField(
                              controller: barcodeController,
                              keyboardType: TextInputType.number,
                              style: const TextStyle(color: Colors.white),
                              decoration: const InputDecoration(
                                hintText: '0045496430528',
                                hintStyle: TextStyle(color: Colors.grey),
                              ),
                            ),
                            actions: [
                              TextButton(
                                onPressed: () => Navigator.pop(dialogContext),
                                child: const Text('Anuluj', style: TextStyle(color: Colors.grey)),
                              ),
                              TextButton(
  onPressed: () async {
    final kod = barcodeController.text.trim();
    if (kod.isNotEmpty) {
      // 1. Zamykamy okienko wpisywania kodu
      Navigator.pop(dialogContext);

      try {
        // 2. Bezpośredni strzał do Firebase omijający BLoC-a (szybko i pewnie)
        final doc = await FirebaseFirestore.instanceFor(app: Firebase.app(), databaseId: 'powornywarka').collection('Produkty').doc(kod).get();

        if (doc.exists && doc.data() != null) {
          final data = doc.data()!;
          
          // 3. Budujemy tekst z danymi produktu pobranymi prosto z chmury
          String opis = "Nazwa: ${data['Nazwa'] ?? 'Brak'}\n"
                        "Marka: ${data['Marka'] ?? 'Brak'}\n"
                        "Kategoria: ${data['Kategoria'] ?? 'Brak'}\n\nCeny:\n";
          
          final ceny = Map<String, dynamic>.from(data['Cena'] ?? {});
          ceny.forEach((sklep, cena) {
            opis += "- $sklep: ${cena} zł\n";
          });

          // 4. Wyświetlamy okienko z sukcesem na ekranie
          showDialog(
            context: context,
            builder: (ctx) => AlertDialog(
              backgroundColor: Colors.grey[900],
              title: const Text("🟢 PRODUKT ZNALEZIONY", style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold)),
              content: Text(opis, style: const TextStyle(color: Colors.white)),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(ctx),
                  child: const Text("Zamknij", style: TextStyle(color: Colors.green)),
                )
              ],
            ),
          );
        } else {
          // Jeśli produktu nie ma w bazie
          showDialog(
            context: context,
            builder: (ctx) => AlertDialog(
              backgroundColor: Colors.grey[900],
              title: const Text("🟡 BRAK PRODUKTU", style: TextStyle(color: Colors.orange, fontWeight: FontWeight.bold)),
              content: Text("Nie znaleziono kodu: $kod w bazie 'powornywarka'.", style: const TextStyle(color: Colors.white)),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(ctx),
                  child: const Text("OK", style: TextStyle(color: Colors.orange)),
                )
              ],
            ),
          );
        }
      } catch (e) {
        // W razie jakiegokolwiek błędu sieciowego
        showDialog(
          context: context,
          builder: (ctx) => AlertDialog(
            backgroundColor: Colors.grey[900],
            title: const Text("🔴 BŁĄD SIECI", style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
            content: Text(e.toString(), style: const TextStyle(color: Colors.white)),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text("Zamknij", style: TextStyle(color: Colors.red)),
              )
            ],
          ),
        );
      }
    }
  },
  child: const Text('Szukaj w bazie', style: TextStyle(color: Colors.green)),
),
                            ],
                          );
                        },
                      );
                    },
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  // TA FUNKCJA WYMUSZA AGRESYWNE POKAZANIE DANYCH NA ŚRODKU EKRANU
  void _showRawDataDialog(BuildContext context, String title, String rawData) {
    showDialog(
      context: context,
      barrierDismissible: false, // Użytkownik musi to kliknąć, nie da się ominąć
      builder: (context) => AlertDialog(
        backgroundColor: Colors.black,
        shape: RoundedRectangleBorder(side: const BorderSide(color: Colors.white, width: 2), borderRadius: BorderRadius.circular(10)),
        title: Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        content: SingleChildScrollView(
          child: Text(rawData, style: const TextStyle(color: Colors.greenAccent, fontSize: 16, fontFamily: 'monospace')),
        ),
        actions: [
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.white),
            onPressed: () {
              Navigator.pop(context);
              context.read<ScannerBloc>().add(const OpenScannerEvent());
            },
            child: const Text("ZAMKNIJ I SKANUJ DALEJ", style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
          )
        ],
      ),
    );
  }
}