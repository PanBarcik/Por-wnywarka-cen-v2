import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../bloc/scanner_bloc.dart';
import '../bloc/scanner_event.dart';
import '../bloc/scanner_state.dart';

class SearchPage extends StatelessWidget {
  const SearchPage({super.key});

  @override
  Widget build(BuildContext context) {
    const accentGreen = Color(0xFF22C55E);
    const cardBackground = Color(0xFF1E293B);

    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 15.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Tytuł sekcji
          const Text(
            'Browse Stores',
            style: TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 20),

          // Główny pasek wyszukiwania z obsługą Speech-to-Text (głosowego) i tekstowego
          TextField(
            style: const TextStyle(color: Colors.white),
            decoration: InputDecoration(
              filled: true,
              fillColor: const Color(0xFF0F172A),
              hintText: 'Search departments or products...',
              hintStyle: TextStyle(color: Colors.grey[500], fontSize: 15),
              prefixIcon: Icon(Icons.search, color: Colors.grey[500]),
              
              // Dynamiczny SuffixIcon: Reaguje na przytrzymanie mikrofonu i zmienia kolor
              suffixIcon: BlocBuilder<ScannerBloc, ScannerState>(
                builder: (context, state) {
                  final isRecording = state is VoiceRecordingState;
                  return GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onLongPressStart: (_) {
                      // Rozpocznij nagrywanie w chmurze Google po przytrzymaniu
                      context.read<ScannerBloc>().add(const StartVoiceSearchEvent());
                    },
                    onLongPressEnd: (_) {
                      // Zatrzymaj nagrywanie i przetwórz mowę po puszczeniu palca
                      context.read<ScannerBloc>().add(const StopVoiceSearchEvent());
                    },
                    child: Icon(
                      Icons.mic, 
                      color: isRecording ? Colors.redAccent : Colors.grey[500],
                      size: 24,
                    ),
                  );
                },
              ),
              contentPadding: const EdgeInsets.symmetric(vertical: 16),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: Colors.grey.withOpacity(0.2)),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: Colors.grey.withOpacity(0.1)),
              ),
            ),
            // Obsługa tradycyjnego wyszukiwania po kliknięciu Enter na klawiaturze
            onSubmitted: (query) {
              if (query.trim().isNotEmpty) {
                context.read<ScannerBloc>().add(SearchProductsEvent(query.trim()));
              }
            },
          ),
          const SizedBox(height: 16),

          // Tagi szybkiego wyszukiwania (Horizontal list)
          SizedBox(
            height: 38,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: [
                _buildSearchTag(Icons.history, 'Power Drills'),
                _buildSearchTag(Icons.history, 'White Paint'),
                _buildSearchTag(Icons.history, 'LED Bulbs'),
              ],
            ),
          ),
          const SizedBox(height: 30),

          // Nagłówek sekcji kategorii
          const Text(
            'DEPARTMENTS',
            style: TextStyle(color: Colors.grey, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1.2),
          ),
          const SizedBox(height: 16),

          // --- ROZWIJANA KATEGORIA: TOOLS & HARDWARE (OTWARTA) ---
          Container(
            margin: const EdgeInsets.only(bottom: 12.0),
            decoration: BoxDecoration(
              color: cardBackground.withOpacity(0.3),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: accentGreen.withOpacity(0.3), width: 1),
            ),
            child: Theme(
              data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
              child: ExpansionTile(
                initiallyExpanded: true, 
                leading: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: accentGreen.withOpacity(0.1),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.build_circle_outlined, color: accentGreen, size: 24),
                ),
                title: const Text('Tools & Hardware', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
                subtitle: Text('Power tools, hand tools, fasteners', style: TextStyle(color: Colors.grey[400], fontSize: 12)),
                trailing: const Icon(Icons.keyboard_arrow_up, color: Colors.grey),
                children: [
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Divider(color: Colors.white10, height: 1),
                        const SizedBox(height: 16),
                        Text('Popular in Tools', style: TextStyle(color: Colors.grey[400], fontSize: 13, fontWeight: FontWeight.w500)),
                        const SizedBox(height: 12),
                        
                        Row(
                          children: [
                            _buildPopularCard('Cordless Drills', '142 items', 'https://images.unsplash.com/photo-1504148455328-c376907d081c?w=200'),
                            const SizedBox(width: 12),
                            _buildPopularCard('Hand Tool Sets', '89 items', 'https://images.unsplash.com/photo-1581244277943-fe4a9c777189?w=200'),
                          ],
                        ),
                        const SizedBox(height: 16),

                        OutlinedButton(
                          style: OutlinedButton.styleFrom(
                            minimumSize: const Size.fromHeight(48),
                            side: const BorderSide(color: Colors.white12),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          ),
                          onPressed: () {},
                          child: const Text('View All Tools', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                        ),
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),

          // --- POZOSTAŁE KATEGORIE (ZAMKNIĘTE) ---
          _buildClosedDepartment(Icons.lightbulb_outline, 'Lighting & Electrical', 'Indoor, outdoor, smart home'),
          _buildClosedDepartment(Icons.layers_outlined, 'Building Materials', 'Lumber, cement, insulation'),
          _buildClosedDepartment(Icons.format_paint_outlined, 'Paint & Decorating', 'Interior paint, exterior, supplies'),
          _buildClosedDepartment(Icons.water_drop_outlined, 'Plumbing & Heating', 'Pipes, radiators, bathroom fittings'),
        ],
      ),
    );
  }

  Widget _buildSearchTag(IconData icon, String label) {
    return Container(
      margin: const EdgeInsets.only(right: 8),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: const Color(0xFF1E293B),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white10),
      ),
      child: Row(
        children: [
          Icon(icon, color: Colors.grey[400], size: 16),
          const SizedBox(width: 6),
          Text(label, style: const TextStyle(color: Colors.white, fontSize: 13)),
        ],
      ),
    );
  }

  Widget _buildClosedDepartment(IconData icon, String title, String subtitle) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12.0),
      decoration: BoxDecoration(
        color: const Color(0xFF1E293B).withOpacity(0.2),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white10),
      ),
      child: ListTile(
        leading: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.05),
            shape: BoxShape.circle,
          ),
          child: Icon(icon, color: Colors.white, size: 24),
        ),
        title: Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
        subtitle: Text(subtitle, style: const TextStyle(color: Colors.grey, fontSize: 12)),
        trailing: const Icon(Icons.keyboard_arrow_down, color: Colors.grey),
        onTap: () {},
      ),
    );
  }

  Widget _buildPopularCard(String title, String count, String imageUrl) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: const Color(0xFF0F172A).withOpacity(0.6),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.white10),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.network(
                imageUrl,
                height: 80,
                width: double.infinity,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) => Container(
                  height: 80,
                  color: Colors.white10,
                  child: const Icon(Icons.image, color: Colors.white24),
                ),
              ),
            ),
            const SizedBox(height: 10),
            Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13)),
            const SizedBox(height: 2),
            Text(count, style: const TextStyle(color: Color(0xFF22C55E), fontSize: 11, fontWeight: FontWeight.w500)),
          ],
        ),
      ),
    );
  }
}