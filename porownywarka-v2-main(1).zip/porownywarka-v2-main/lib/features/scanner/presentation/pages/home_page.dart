import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../bloc/scanner_bloc.dart';
import '../bloc/scanner_event.dart';
import '../bloc/scanner_state.dart';
import '../widgets/store_grid.dart';
import '../widgets/scan_banner.dart';
import '../widgets/last_scanned_list.dart';
import 'camera_page.dart'; 
import 'search_page.dart'; 
import 'profile_page.dart'; // <--- DODANO: Import podstrony profilu z kroku 3

class HomePage extends StatelessWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    const backgroundColor = Color(0xFF111827);
    const accentGreen = Color(0xFF22C55E);

    return BlocBuilder<ScannerBloc, ScannerState>(
      builder: (context, state) {
        final isCamera = state is ScannerCameraState;
        final isSearch = state is ScannerSearchState;
        final isProfile = state is ScannerProfileState; // <--- DODANO: Sprawdzanie nowego stanu profilu

        return Scaffold(
          backgroundColor: backgroundColor,
          
          // --- DYNAMICZNY ŚRODEK (BODY) ---
          body: SafeArea(
            child: _buildBody(state, accentGreen),
          ),
          
          // --- PASEK DOLNY (Z PEWNYMI STREFAMI KLIKNIĘCIA) ---
          bottomNavigationBar: BottomAppBar(
            color: const Color(0xFF0F172A),
            child: SizedBox(
              height: 60,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  // Przycisk HOME
                  Expanded(
                    child: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: () => context.read<ScannerBloc>().add(const BackToHomeEvent()),
                      child: _buildNavItem(
                        Icons.home, 
                        'Home', 
                        state is ScannerHomeState || (!isSearch && !isCamera && !isProfile), 
                        accentGreen,
                      ),
                    ),
                  ),

                  // Przycisk SEARCH
                  Expanded(
                    child: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: () => context.read<ScannerBloc>().add(const OpenSearchEvent()),
                      child: _buildNavItem(Icons.search, 'Search', isSearch, accentGreen),
                    ),
                  ),
                  
                  // ŚRODKOWY ZIELONY PRZYCISK APARATU
                  GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: () {
                      final bloc = context.read<ScannerBloc>();
                      if (bloc.state is ScannerCameraState) {
                        bloc.add(const BackToHomeEvent());
                      } else {
                        bloc.add(const OpenScannerEvent());
                      }
                    },
                    child: Container(
                      width: 55,
                      height: 55,
                      decoration: BoxDecoration(
                        color: accentGreen,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: accentGreen.withOpacity(0.3), 
                            blurRadius: 8, 
                            spreadRadius: 1,
                          ),
                        ],
                      ),
                      child: Icon(
                        isCamera ? Icons.close : Icons.center_focus_weak, 
                        color: Colors.black, 
                        size: 26,
                      ),
                    ),
                  ),
                  
                  // Przycisk LIST
                  Expanded(
                    child: _buildNavItem(Icons.list_alt, 'List', false, accentGreen),
                  ),
                  
                  // Przycisk PROFILE (Uaktywniony z kroku 3!)
                  Expanded(
                    child: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: () => context.read<ScannerBloc>().add(const OpenProfileEvent()), // <--- DODANO: Wywołanie eventu z BLoCa
                      child: _buildNavItem(Icons.person_outline, 'Profile', isProfile, accentGreen), // <--- DODANO: Reakcja na aktywny stan
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // Funkcja decydująca o tym, co rysujemy na środku ekranu
  Widget _buildBody(ScannerState state, Color accentGreen) {
    if (state is ScannerCameraState) {
      return const CameraPage();
    }

    if (state is ScannerSearchState) {
      return const SearchPage();
    }

    if (state is ScannerProfileState) {
      return const ProfilePage(); // <--- DODANO: Wyświetlanie nowej strony profilu na środku ekranu
    }

    if (state is ScannerLoading) {
      return Center(child: CircularProgressIndicator(color: accentGreen));
    }

    // Domyślny pulpit z powitaniem Alexa
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 15.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Good evening, Alex',
                    style: TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 4),
                  Text('Ready to find some deals?', style: TextStyle(color: Colors.grey[400], fontSize: 14)),
                ],
              ),
              const CircleAvatar(
                radius: 25,
                backgroundImage: NetworkImage('https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100'),
              ),
            ],
          ),
          const SizedBox(height: 30),
          const Text('MAJOR STORES', style: TextStyle(color: Colors.grey, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1.2)),
          const SizedBox(height: 12),
          const StoreGrid(),
          const SizedBox(height: 25),
          const ScanBanner(),
          const SizedBox(height: 30),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('LAST SCANNED', style: TextStyle(color: Colors.grey, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1.2)),
              TextButton(onPressed: () {}, child: Text('View All', style: TextStyle(color: accentGreen))),
            ],
          ),
          const SizedBox(height: 10),
          const LastScannedList(),
        ],
      ),
    );
  }

  Widget _buildNavItem(IconData icon, String label, bool isActive, Color activeColor) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(icon, color: isActive ? activeColor : Colors.grey[600], size: 24),
        const SizedBox(height: 4),
        Text(label, style: TextStyle(color: isActive ? activeColor : Colors.grey[600], fontSize: 10)),
      ],
    );
  }
}