import 'package:flutter/material.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    const accentGreen = Color(0xFF22C55E);
    const cardBackground = Color(0xFF1E293B);
    const sectionTitleStyle = TextStyle(color: Colors.grey, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1.2);

    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 15.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Nagłówek: Tytuł i Powiadomienia
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Profile & Settings', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
              Stack(
                children: [
                  IconButton(icon: const Icon(Icons.notifications_none, color: Colors.white, size: 28), onPressed: () {}),
                  Positioned(
                    right: 12,
                    top: 12,
                    child: Container(height: 8, width: 8, decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle)),
                  )
                ],
              ),
            ],
          ),
          const SizedBox(height: 25),

          // KARTA PROFILU
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(color: cardBackground, borderRadius: BorderRadius.circular(24)),
            child: Row(
              children: [
                Stack(
                  alignment: Alignment.bottomRight,
                  children: [
                    const CircleAvatar(
                      radius: 40,
                      backgroundImage: NetworkImage('https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200'),
                    ),
                    Container(
                      padding: const EdgeInsets.all(3),
                      decoration: const BoxDecoration(color: Color(0xFF111827), shape: BoxShape.circle),
                      child: const Icon(Icons.circle, color: accentGreen, size: 14),
                    ),
                  ],
                ),
                const SizedBox(width: 20),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Alex Mercer', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                      const Text('alex.mercer@example.com', style: TextStyle(color: Colors.grey, fontSize: 13)),
                      const SizedBox(height: 10),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.black26, 
                          borderRadius: BorderRadius.circular(20), 
                          border: Border.all(color: accentGreen.withValues(alpha: 0.5)), // Nowoczesne przypisanie przezroczystości
                        ),
                        child: const Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.star, color: accentGreen, size: 14),
                            SizedBox(width: 4),
                            Text('Pro Member', style: TextStyle(color: accentGreen, fontSize: 11, fontWeight: FontWeight.bold)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const Icon(Icons.edit_outlined, color: Colors.grey, size: 20),
              ],
            ),
          ),
          const SizedBox(height: 35),

          // SHOPPING PREFERENCES
          const Text('SHOPPING PREFERENCES', style: sectionTitleStyle),
          const SizedBox(height: 15),
          _buildSettingsItem(Icons.storefront, 'Default Store', 'Leroy Merlin'),
          _buildSettingsItem(Icons.public, 'Region & Currency', 'Poland (PLN zł)'),
          
          const SizedBox(height: 35),

          // APP SETTINGS
          const Text('APP SETTINGS', style: sectionTitleStyle),
          const SizedBox(height: 15),
          _buildToggleItem(Icons.dark_mode_outlined, 'Dark Mode', 'App appearance', true),
          _buildToggleItem(Icons.notifications_active_outlined, 'Price Alerts', 'Notify on saved items', true),
          _buildToggleItem(Icons.notifications_outlined, 'Notifications', 'Updates & reminders', true),
          
          const SizedBox(height: 35),

          // PRIVACY & SECURITY
          const Text('PRIVACY & SECURITY', style: sectionTitleStyle),
          const SizedBox(height: 15),
          _buildSettingsItem(Icons.camera_alt_outlined, 'Camera Access', 'Required for barcode scanner'),
          _buildSettingsItem(Icons.lock_outline, 'Data & Privacy', 'Manage your data'),
          
          const SizedBox(height: 15),
          // LOGOUT
          Container(
            margin: const EdgeInsets.only(top: 10),
            decoration: BoxDecoration(color: const Color(0xFFEF4444).withValues(alpha: 0.1), borderRadius: BorderRadius.circular(16)),
            child: ListTile(
              leading: const Icon(Icons.logout, color: Color(0xFFEF4444)),
              title: const Text('Log Out', style: TextStyle(color: Color(0xFFEF4444), fontWeight: FontWeight.bold)),
              onTap: () {},
            ),
          ),
          const SizedBox(height: 40),
        ],
      ),
    );
  }

  // Widget dla pozycji z przełącznikiem (Toggle)
  Widget _buildToggleItem(IconData icon, String title, String subtitle, bool value) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12.0), // POPRAWIONO: Zmieniono z EdgeInsets.bottom na EdgeInsets.only
      decoration: BoxDecoration(color: const Color(0xFF1E293B).withValues(alpha: 0.5), borderRadius: BorderRadius.circular(16)),
      child: ListTile(
        leading: Icon(icon, color: Colors.white70),
        title: Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 15)),
        subtitle: Text(subtitle, style: const TextStyle(color: Colors.grey, fontSize: 12)),
        trailing: Switch.adaptive(
          value: value,
          onChanged: (v) {},
          activeColor: const Color(0xFF22C55E),
        ),
      ),
    );
  }

  // Widget dla standardowej pozycji nawigacyjnej
  Widget _buildSettingsItem(IconData icon, String title, String subtitle) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12.0), // POPRAWIONO: Zmieniono z EdgeInsets.bottom na EdgeInsets.only
      decoration: BoxDecoration(color: const Color(0xFF1E293B).withValues(alpha: 0.5), borderRadius: BorderRadius.circular(16)),
      child: ListTile(
        leading: Icon(icon, color: Colors.white70),
        title: Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 15)),
        subtitle: Text(subtitle, style: const TextStyle(color: Colors.grey, fontSize: 12)),
        trailing: const Icon(Icons.keyboard_arrow_right, color: Colors.grey),
        onTap: () {},
      ),
    );
  }
}