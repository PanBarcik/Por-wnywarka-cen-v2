import 'package:flutter/material.dart';
import '../../data/models/product_model.dart';

class LastScannedList extends StatelessWidget {
  const LastScannedList({Key? key}) : super(key: key);

  // Poprawny mock danych przeniesiony bezpośrednio jako stała lista obiektów
  static const List<ProductModel> mockProducts = [
    ProductModel(
      title: 'Bosch Professional Drill',
      timeAgo: 'Scanned 2 hours ago',
      currentPrice: 549,
      oldPrice: 619,
      storeName: 'Castorama',
      competitorStoreName: 'Leroy Merlin',
      imageUrl: 'https://images.unsplash.com/photo-1504148455328-c376907d081c?w=300',
    ),
    ProductModel(
      title: 'Dulux Wall Paint 5L',
      timeAgo: 'Scanned yesterday',
      currentPrice: 189,
      storeName: 'Obi',
      imageUrl: 'https://images.unsplash.com/photo-1562259949-e8e7689d7828?w=300',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    const accentGreen = Color(0xFF22C55E);

    return SizedBox(
      height: 280,
      child: ListView.separated(
        scrollDirection: Axis.horizontal, // <-- Poprawione z Alignment.horizontal na Axis.horizontal
        itemCount: mockProducts.length,
        separatorBuilder: (context, index) => const SizedBox(width: 16),
        itemBuilder: (context, index) {
          final product = mockProducts[index];
          return Container(
            width: 220,
            decoration: BoxDecoration(
              color: const Color(0xFF1F2937),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Stack(
                  children: [
                    ClipRRect(
                      borderRadius: const BorderRadius.only(
                        topLeft: Radius.circular(20),
                        topRight: Radius.circular(20),
                      ),
                      child: Image.network(
                        product.imageUrl,
                        height: 130,
                        width: double.infinity,
                        fit: BoxFit.cover,
                      ),
                    ),
                    if (product.hasBestPrice)
                      Positioned(
                        top: 10,
                        right: 10,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: accentGreen.withOpacity(0.9),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Text(
                            'Best Price',
                            style: TextStyle(
                              color: Colors.black,
                              fontSize: 11,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        product.title,
                        style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.bold),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 4),
                      Text(product.timeAgo, style: TextStyle(color: Colors.grey[500], fontSize: 11)),
                      const SizedBox(height: 12),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('${product.currentPrice.toInt()} zł', style: const TextStyle(color: accentGreen, fontSize: 20, fontWeight: FontWeight.bold)),
                              Text('at ${product.storeName}', style: TextStyle(color: Colors.grey[400], fontSize: 11)),
                            ],
                          ),
                          if (product.hasBestPrice)
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Text('${product.oldPrice?.toInt()} zł', style: TextStyle(color: Colors.grey[500], fontSize: 12, decoration: TextDecoration.lineThrough)),
                                Text(product.competitorStoreName ?? '', style: const TextStyle(color: Colors.redAccent, fontSize: 11)),
                              ],
                            ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}