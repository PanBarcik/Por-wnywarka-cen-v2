import 'package:flutter/material.dart';
import '../../data/models/store_model.dart';

class StoreGrid extends StatelessWidget {
  final List<StoreModel> stores = const [
    StoreModel(name: 'Castorama', icon: Icons.construction),
    StoreModel(name: 'Leroy Merlin', icon: Icons.format_paint),
    StoreModel(name: 'Obi', icon: Icons.build),
  ];

  const StoreGrid({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: stores.map((store) {
        return Expanded(
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 6.0),
            padding: const EdgeInsets.symmetric(vertical: 20),
            decoration: BoxDecoration(
              color: const Color(0xFF1F2937),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(store.icon, color: Colors.white, size: 24),
                const SizedBox(height: 10),
                Text(
                  store.name,
                  style: const TextStyle(
                    color: Colors.white, 
                    fontSize: 13, 
                    fontWeight: FontWeight.w500,
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        );
      }).toList(),
    );
  }
}