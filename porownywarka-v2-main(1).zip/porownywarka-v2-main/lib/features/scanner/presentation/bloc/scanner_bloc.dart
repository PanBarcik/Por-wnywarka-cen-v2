import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';

// Wskazujemy bezwzględną, bezpieczną ścieżkę do głównego modelu aplikacji
import 'package:pricecomparison/data/models/product_model.dart';

import '../../data/models/store_model.dart';
import '../../data/cloud_vision_service.dart';
import '../../data/speech_to_text_service.dart';

import 'scanner_event.dart';
import 'scanner_state.dart';

class ScannerBloc extends Bloc<ScannerEvent, ScannerState> {
  final CloudVisionService _visionService = CloudVisionService();
  final FirebaseFirestore _firestore = FirebaseFirestore.instanceFor(app: Firebase.app(), databaseId: 'powornywarka');
  final SpeechToTextService _speechService = SpeechToTextService();

  ScannerBloc() : super(const ScannerHomeState()) {
    
    // --- OBSŁUGA NAWIGACJI ---
    on<OpenScannerEvent>((event, emit) {
      emit(const ScannerCameraState());
    });

    on<BackToHomeEvent>((event, emit) {
      emit(const ScannerHomeState());
    });

    on<OpenSearchEvent>((event, emit) {
      emit(const ScannerSearchState());
    });

    // --- LOGIKA WYSZUKIWANIA RĘCZNEGO ---
    on<SearchProductsEvent>((event, emit) async {
      emit(ScannerLoading());
      try {
        final doc = await _firestore.collection('Produkty').doc(event.query).get();
        
        if (doc.exists) {
          final data = doc.data();
          if (data != null) {
            // Bezpiecznie wyciągamy mapę cen i rzutujemy ją na format oczekiwany przez główny model aplikacji
            final cenyRaw = Map<String, dynamic>.from(data['Cena'] ?? {});
            final Map<String, double> cenyMap = cenyRaw.map(
              (key, value) => MapEntry(key, (value as num).toDouble()),
            );

            // Tworzymy obiekt ProductModel używając oryginalnych, polskich parametrów
            final produkt = ProductModel(
              ean: event.query,
              nazwa: data['Nazwa'] ?? 'Brak nazwy',
              marka: data['Marka'] ?? 'Brak marki',
              kategoria: data['Kategoria'] ?? 'Brak kategorii',
              ceny: cenyMap,
            );
            
            emit(ProductFound(produkt));
          } else {
            emit(ProductNotFound(event.query));
          }
        } else {
          emit(ProductNotFound(event.query));
        }
      } catch (e) {
        emit(ScannerError(e.toString()));
      }
    });
  }
}