import '../../../../data/models/product_model.dart'; // Upewnij się, że ścieżka do modelu jest poprawna

abstract class ScannerState {
  const ScannerState();
}

// --- STANY NAWIGACYJNE (Zarządzanie ekranami) ---

/// Stan początkowy / Pulpit główny (Dashboard z Castoramą, OBI, itp.)
class ScannerHomeState extends ScannerState {
  const ScannerHomeState();
}

/// Stan otwartego aparatu (Użytkownik widzi podgląd z kamery i celuje w kod)
class ScannerCameraState extends ScannerState {
  const ScannerCameraState();
}

/// Stan otwartego ekranu wyszukiwania / przeglądania sklepów (Nowy stan!)
class ScannerSearchState extends ScannerState {
  const ScannerSearchState();
}

class ScannerProfileState extends ScannerState {
  const ScannerProfileState();
}


// --- STANY LOGICZNE (Przetwarzanie i wyszukiwanie produktu) ---

/// Stan ładowania (Wywoływany po zrobieniu zdjęcia, gdy kręci się Loader/Spinner,
/// a Cloud Vision i Firestore szukają danych w tle)
class ScannerLoading extends ScannerState {
  const ScannerLoading();
}

/// Sukces: Produkt został bezbłędnie znaleziony w bazie Firestore.
/// Przekazujemy obiekt produktu, aby ekran mógł wyświetlić jego cenę i szczegóły.
class ProductFound extends ScannerState {
  final ProductModel product;

  const ProductFound(this.product);
}

class SearchLoading extends ScannerState { const SearchLoading(); }
class SearchResultsFound extends ScannerState {
  final List<ProductModel> products;
  const SearchResultsFound(this.products);
}
class VoiceRecordingState extends ScannerState { const VoiceRecordingState(); }

/// Informacja: Kod kreskowy został odczytany, ale nie ma takiego produktu w bazie Firestore.
/// Przekazujemy sam kod EAN, np. żeby wyświetlić komunikat "Chcesz dodać ten produkt?".
class ProductNotFound extends ScannerState {
  final String ean;

  const ProductNotFound(this.ean);
}

/// Błąd: Coś poszło nie tak (np. brak internetu, błąd Google Cloud Vision, 
/// albo zdjęcie było zbyt rozmazane, by odczytać kod)
class ScannerError extends ScannerState {
  final String message;

  const ScannerError(this.message);
}