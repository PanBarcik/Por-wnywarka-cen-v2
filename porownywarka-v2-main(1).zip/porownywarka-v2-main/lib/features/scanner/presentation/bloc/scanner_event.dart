import 'dart:io';

abstract class ScannerEvent {
  const ScannerEvent();
}

// --- EVENTY NAWIGACYJNE (Zarządzanie ekranami) ---

/// Event wywoływany, gdy użytkownik kliknie środkowy przycisk
/// i chcemy otworzyć aparat (ekran skanowania)
class OpenScannerEvent extends ScannerEvent {
  const OpenScannerEvent();
}

/// Event wywoływany, gdy użytkownik chce wrócić z aparatu
/// na główny pulpit (ekran Home)
class BackToHomeEvent extends ScannerEvent {
  const BackToHomeEvent();
}

/// Event wywoływany, gdy użytkownik kliknie ikonę wyszukiwania (lupę)
/// na dolnym pasku nawigacji (Nowy event!)
class OpenSearchEvent extends ScannerEvent {
  const OpenSearchEvent();
}

class OpenProfileEvent extends ScannerEvent {
  const OpenProfileEvent();
}


// --- EVENTY LOGICZNE (Proces skanowania) ---

/// Twój obecny event – wywoływany, gdy aparat pomyślnie przechwyci
/// zdjęcie kodu kreskowego i przekazuje plik do przetworzenia
class PhotoCaptured extends ScannerEvent {
  final File image;
  
  const PhotoCaptured(this.image);
}

class StartVoiceSearchEvent extends ScannerEvent { const StartVoiceSearchEvent(); }
class StopVoiceSearchEvent extends ScannerEvent { const StopVoiceSearchEvent(); }
class SearchProductsEvent extends ScannerEvent {
  final String query;
  const SearchProductsEvent(this.query);
}